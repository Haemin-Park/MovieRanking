package phm.example.movieranking.model.enum

enum class KakaoSearchSortEnum(val sort:String){
    Accuracy("accuracy"),
    Recency("recency")
}